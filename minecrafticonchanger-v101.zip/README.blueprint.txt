BLUEPRINT INSTALLATION

Downloaded addon: Minecraft Icon Changer 1.0.1
Author: 0x7d8

(!) BLUEPRINT:
Make sure blueprint is installed fully using the steps from
  https://blueprint.zip/docs/?page=getting-started/Installation

 - Installation of the addon:
  1. Copy minecrafticonchanger.blueprint to your pterodactyl folder (usually /var/www/pterodactyl)
  2. Run
    blueprint -install minecrafticonchanger
  3. Done!

 - Updating the addon:
  1. Copy the new minecrafticonchanger.blueprint to your pterodactyl folder
  2. Run
    blueprint -install minecrafticonchanger
  3. Done!

 - Removing the addon: (only if you want to remove the addon, not update)
  1. Run
    blueprint -remove minecrafticonchanger
  2. Done!