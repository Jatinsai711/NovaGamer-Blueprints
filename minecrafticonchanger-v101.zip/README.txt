Thank you for your purchase!
Downloaded addon: Minecraft Icon Changer 1.0.1
Author: 0x7d8

(i) BLUEPRINT: (https://blueprint.zip/)
View the README.blueprint.txt file for instructions on how to install the addon using blueprint

(i) STANDALONE: (ainx)
View the README.standalone.txt file for instructions on how to install the addon using ainx (for standalone installations)