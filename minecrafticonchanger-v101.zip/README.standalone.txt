STANDALONE INSTALLATION

Downloaded addon: Minecraft Icon Changer 1.0.1
Author: 0x7d8

(i) Patch-based Installation:
For detailed instructions on how to install the addon using a patch, visit https://ainx.dev/ainx/addons/patches

(!) How to install the addon after updating the panel:
If you have updated the panel and need to reinstall the addon, you can use the following command
  ainx install minecrafticonchanger.ainx --force
To reinstall all addons at once you can use
  ainx install *.ainx --force

(!) STANDALONE:
For detailed instructions on how to install the addon using ainx, you can visit https://ainx.dev/ainx/addons/installation
Make sure NodeJS 16+ and Yarn are installed on your system, you can use the install-ainx.sh script to install them.
To install ainx either run the script or run
  npm install -g ainx

 - Installation of the addon:
  1. Run
    ainx install minecrafticonchanger.ainx
  2. Follow any on-screen instructions if present, you can always exit while installing and run the command again
  3. Done!

 - Updating the addon:
  1. Run
    ainx upgrade minecrafticonchanger.ainx
  2. Done!

 - Updating the addon without rebuilding frontend (for modified frontends):
  1. Run
    ainx upgrade minecrafticonchanger.ainx --rebuild=false --skipSteps
  2. Done!

 - Removing the addon:
  1. Run
    ainx remove minecrafticonchanger
  2. Follow any on-screen instructions if present, you can always exit while removing and run the command again
  3. Done!